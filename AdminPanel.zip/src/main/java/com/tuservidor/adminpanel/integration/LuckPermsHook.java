package com.tuservidor.adminpanel.integration;

import com.tuservidor.adminpanel.AdminPanelPlugin;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.entity.Player;

/**
 * Integracion opcional con LuckPerms. Si el plugin LuckPerms no esta instalado,
 * o falla la inicializacion, todo el plugin sigue funcionando con los permisos
 * nativos de Bukkit ({@link Player#hasPermission(String)}).
 */
public class LuckPermsHook {

    private final AdminPanelPlugin plugin;
    private LuckPerms luckPerms;
    private boolean enabled;

    public LuckPermsHook(AdminPanelPlugin plugin) {
        this.plugin = plugin;
    }

    /** Intenta enganchar con la API de LuckPerms. Devuelve true si tuvo exito. */
    public boolean setup() {
        if (plugin.getServer().getPluginManager().getPlugin("LuckPerms") == null) {
            this.enabled = false;
            return false;
        }

        try {
            this.luckPerms = LuckPermsProvider.get();
            this.enabled = true;
        } catch (IllegalStateException ex) {
            plugin.getLogger().warning("LuckPerms esta instalado pero su API no esta lista todavia: " + ex.getMessage());
            this.enabled = false;
        }

        return enabled;
    }

    public boolean isEnabled() {
        return enabled && luckPerms != null;
    }

    /** Comprueba un permiso via LuckPerms; si algo falla, recurre a Bukkit. */
    public boolean hasPermission(Player player, String node) {
        if (!isEnabled()) {
            return player.hasPermission(node);
        }

        try {
            User user = luckPerms.getUserManager().getUser(player.getUniqueId());
            if (user == null) {
                return player.hasPermission(node);
            }
            return user.getCachedData().getPermissionData().checkPermission(node).asBoolean();
        } catch (Exception ex) {
            return player.hasPermission(node);
        }
    }
}
