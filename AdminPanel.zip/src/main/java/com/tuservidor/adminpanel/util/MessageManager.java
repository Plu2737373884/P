package com.tuservidor.adminpanel.util;

import com.tuservidor.adminpanel.config.ConfigManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.file.FileConfiguration;

/**
 * Centraliza la carga y el formateo de todos los mensajes del plugin.
 * Los mensajes se escriben en config.yml usando el formato MiniMessage
 * (por ejemplo: "<green>Hola {player}</green>").
 */
public class MessageManager {

    private final ConfigManager configManager;
    private final MiniMessage miniMessage;

    public MessageManager(ConfigManager configManager) {
        this.configManager = configManager;
        this.miniMessage = MiniMessage.miniMessage();
    }

    /** No mantiene estado propio: los mensajes siempre se leen de ConfigManager. */
    public void reload() {
        // Intencionalmente vacio.
    }

    private FileConfiguration raw() {
        return configManager.raw();
    }

    public String getPrefix() {
        return raw().getString("messages.prefix", "<gray>[<gold>AdminPanel</gold>]</gray> ");
    }

    /** Obtiene un mensaje por clave, con el prefijo del plugin ya incluido. */
    public Component get(String key) {
        String rawMessage = raw().getString("messages." + key, "<red>Mensaje no encontrado: " + key + "</red>");
        return miniMessage.deserialize(getPrefix() + rawMessage);
    }

    /** Igual que {@link #get(String)} pero reemplaza un placeholder tipo {nombre}. */
    public Component get(String key, String placeholder, String value) {
        String rawMessage = raw().getString("messages." + key, "<red>Mensaje no encontrado: " + key + "</red>");
        rawMessage = rawMessage.replace("{" + placeholder + "}", value);
        return miniMessage.deserialize(getPrefix() + rawMessage);
    }

    /** Parsea cualquier cadena MiniMessage suelta (usado por los GUIs). */
    public Component parse(String rawMiniMessage) {
        return miniMessage.deserialize(rawMiniMessage);
    }
}
