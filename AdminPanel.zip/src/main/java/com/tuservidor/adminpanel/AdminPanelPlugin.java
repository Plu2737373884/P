package com.tuservidor.adminpanel;

import com.tuservidor.adminpanel.commands.AdminCommand;
import com.tuservidor.adminpanel.config.ConfigManager;
import com.tuservidor.adminpanel.gui.GUIListener;
import com.tuservidor.adminpanel.integration.LuckPermsHook;
import com.tuservidor.adminpanel.logs.ActionLogger;
import com.tuservidor.adminpanel.permissions.PermissionManager;
import com.tuservidor.adminpanel.util.MessageManager;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Clase principal del plugin AdminPanel.
 * Se encarga de inicializar todos los modulos (config, mensajes, permisos,
 * logs, integracion con LuckPerms) y de registrar comandos y listeners.
 */
public final class AdminPanelPlugin extends JavaPlugin {

    private static AdminPanelPlugin instance;

    private ConfigManager configManager;
    private MessageManager messageManager;
    private PermissionManager permissionManager;
    private ActionLogger actionLogger;
    private LuckPermsHook luckPermsHook;

    @Override
    public void onEnable() {
        instance = this;

        // 1. Configuracion
        saveDefaultConfig();
        this.configManager = new ConfigManager(this);
        this.messageManager = new MessageManager(this.configManager);

        // 2. Logs de acciones
        this.actionLogger = new ActionLogger(this);

        // 3. Integracion opcional con LuckPerms
        this.luckPermsHook = new LuckPermsHook(this);
        if (configManager.isLuckPermsEnabled() && luckPermsHook.setup()) {
            getLogger().info("Integracion con LuckPerms activada correctamente.");
        } else {
            getLogger().info("LuckPerms no detectado o desactivado. Usando permisos nativos de Bukkit.");
        }

        // 4. Sistema de permisos (usa LuckPerms si esta disponible, si no cae a Bukkit)
        this.permissionManager = new PermissionManager(this);

        // 5. Comandos
        AdminCommand adminCommand = new AdminCommand(this);
        var command = getCommand("adminpanel");
        if (command != null) {
            command.setExecutor(adminCommand);
            command.setTabCompleter(adminCommand);
        }

        // 6. Listeners (clics en los inventarios del panel)
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);

        getLogger().info("AdminPanel habilitado correctamente. Version: " + getDescription().getVersion());
    }

    @Override
    public void onDisable() {
        if (actionLogger != null) {
            actionLogger.close();
        }
        getLogger().info("AdminPanel deshabilitado.");
    }

    /**
     * Recarga config.yml y los modulos que dependen de el.
     */
    public void reload() {
        reloadConfig();
        configManager.reload();
        messageManager.reload();
    }

    public static AdminPanelPlugin getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public PermissionManager getPermissionManager() {
        return permissionManager;
    }

    public ActionLogger getActionLogger() {
        return actionLogger;
    }

    public LuckPermsHook getLuckPermsHook() {
        return luckPermsHook;
    }
}
