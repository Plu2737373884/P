package com.tuservidor.adminpanel.config;

import com.tuservidor.adminpanel.AdminPanelPlugin;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;

/**
 * Envuelve el acceso a config.yml: lectura de ajustes, lista de jugadores
 * autorizados y nodos de permiso configurables.
 */
public class ConfigManager {

    private final AdminPanelPlugin plugin;
    private FileConfiguration config;

    public ConfigManager(AdminPanelPlugin plugin) {
        this.plugin = plugin;
        this.config = plugin.getConfig();
    }

    /** Vuelve a leer la configuracion ya recargada por el plugin. */
    public void reload() {
        this.config = plugin.getConfig();
    }

    public boolean isLuckPermsEnabled() {
        return config.getBoolean("settings.use-luckperms", true);
    }

    public boolean isBroadcastActionsEnabled() {
        return config.getBoolean("settings.broadcast-actions", false);
    }

    public boolean isLoggingEnabled() {
        return config.getBoolean("logs.enabled", true);
    }

    public String getLogFileName() {
        return config.getString("logs.file", "logs/actions.log");
    }

    public List<String> getAuthorizedPlayers() {
        List<String> list = config.getStringList("authorized-players");
        return list != null ? new ArrayList<>(list) : new ArrayList<>();
    }

    public void addAuthorizedPlayer(String name) {
        List<String> list = getAuthorizedPlayers();
        if (!containsIgnoreCase(list, name)) {
            list.add(name);
            config.set("authorized-players", list);
            plugin.saveConfig();
        }
    }

    public void removeAuthorizedPlayer(String name) {
        List<String> list = getAuthorizedPlayers();
        list.removeIf(p -> p.equalsIgnoreCase(name));
        config.set("authorized-players", list);
        plugin.saveConfig();
    }

    public boolean isAuthorized(String name) {
        return containsIgnoreCase(getAuthorizedPlayers(), name);
    }

    private boolean containsIgnoreCase(List<String> list, String value) {
        for (String s : list) {
            if (s.equalsIgnoreCase(value)) {
                return true;
            }
        }
        return false;
    }

    /** Devuelve el nodo de permiso configurado para una clave, o el valor por defecto. */
    public String getPermissionNode(String key, String def) {
        return config.getString("permissions." + key, def);
    }

    /** Acceso directo a la configuracion cruda, usado por MessageManager. */
    public FileConfiguration raw() {
        return config;
    }
}
