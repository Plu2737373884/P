package com.tuservidor.adminpanel.gui;

import com.tuservidor.adminpanel.AdminPanelPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Menu para ver y retirar jugadores autorizados.
 * Cada jugador se muestra como una cabeza; al hacer clic se retira su autorizacion.
 */
public class PlayerManagementGUI implements InventoryHolder {

    public static final int SIZE = 54;

    private final AdminPanelPlugin plugin;
    private Inventory inventory;

    public PlayerManagementGUI(AdminPanelPlugin plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        String title = plugin.getConfig().getString("messages.gui-title-players", "<dark_gray>Gestion de Jugadores");
        this.inventory = Bukkit.createInventory(this, SIZE, plugin.getMessageManager().parse(title));

        List<String> authorized = plugin.getConfigManager().getAuthorizedPlayers();

        int slot = 0;
        for (String name : authorized) {
            if (slot >= 45) break;
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(name);
            inventory.setItem(slot, createSkull(offlinePlayer, name));
            slot++;
        }

        inventory.setItem(49, backButton());

        player.openInventory(inventory);
    }

    private ItemStack createSkull(OfflinePlayer offlinePlayer, String name) {
        ItemStack item = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        meta.setOwningPlayer(offlinePlayer);
        meta.displayName(plugin.getMessageManager().parse("<yellow>" + name));
        meta.lore(List.of(plugin.getMessageManager().parse("<gray>Clic para retirar autorizacion")));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack backButton() {
        ItemStack item = new ItemStack(Material.ARROW);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plugin.getMessageManager().parse("<gray>Volver"));
        item.setItemMeta(meta);
        return item;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
