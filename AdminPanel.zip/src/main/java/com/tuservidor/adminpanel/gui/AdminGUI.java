package com.tuservidor.adminpanel.gui;

import com.tuservidor.adminpanel.AdminPanelPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Menu principal del panel de administracion.
 * Implementa InventoryHolder para poder identificar de forma fiable
 * los clics que pertenecen a este GUI (en vez de comparar titulos).
 */
public class AdminGUI implements InventoryHolder {

    public static final int SIZE = 27;

    private final AdminPanelPlugin plugin;
    private Inventory inventory;

    public AdminGUI(AdminPanelPlugin plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        String title = plugin.getConfig().getString("messages.gui-title-main", "<dark_gray>Panel de Administracion");
        this.inventory = Bukkit.createInventory(this, SIZE, plugin.getMessageManager().parse(title));

        inventory.setItem(11, createItem(Material.PLAYER_HEAD, "<green>Gestion de Jugadores",
                List.of("<gray>Ver y gestionar jugadores autorizados")));
        inventory.setItem(13, createItem(Material.BOOK, "<yellow>Informacion del Servidor",
                List.of("<gray>Ver TPS, jugadores en linea y version")));
        inventory.setItem(15, createItem(Material.COMMAND_BLOCK, "<aqua>Recargar Configuracion",
                List.of("<gray>Vuelve a cargar config.yml")));
        inventory.setItem(22, createItem(Material.BARRIER, "<red>Cerrar", List.of()));

        player.openInventory(inventory);
    }

    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plugin.getMessageManager().parse(name));
        if (!lore.isEmpty()) {
            meta.lore(lore.stream().map(plugin.getMessageManager()::parse).toList());
        }
        item.setItemMeta(meta);
        return item;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
