package com.tuservidor.adminpanel.gui;

import com.tuservidor.adminpanel.AdminPanelPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

/**
 * Escucha los clics en los inventarios propios del plugin.
 * Se identifica cada GUI por su InventoryHolder (AdminGUI / PlayerManagementGUI),
 * nunca por titulo, para evitar falsos positivos con otros plugins.
 */
public class GUIListener implements Listener {

    private final AdminPanelPlugin plugin;

    public GUIListener(AdminPanelPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        var holder = event.getInventory().getHolder();

        if (holder instanceof AdminGUI) {
            event.setCancelled(true);
            handleAdminGuiClick(event);
        } else if (holder instanceof PlayerManagementGUI) {
            event.setCancelled(true);
            handlePlayerManagementClick(event);
        }
    }

    private void handleAdminGuiClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        switch (event.getRawSlot()) {
            case 11 -> {
                if (plugin.getPermissionManager().canManagePlayers(player)) {
                    new PlayerManagementGUI(plugin).open(player);
                } else {
                    player.sendMessage(plugin.getMessageManager().get("no-permission"));
                }
            }
            case 13 -> {
                player.closeInventory();
                player.performCommand("adminpanel info");
            }
            case 15 -> {
                player.closeInventory();
                player.performCommand("adminpanel reload");
            }
            case 22 -> player.closeInventory();
            default -> { /* clic fuera de los botones definidos */ }
        }
    }

    private void handlePlayerManagementClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        if (event.getRawSlot() == 49) {
            new AdminGUI(plugin).open(player);
            return;
        }

        if (clicked.getItemMeta() instanceof SkullMeta skullMeta && skullMeta.getOwningPlayer() != null) {
            String name = skullMeta.getOwningPlayer().getName();
            if (name != null) {
                plugin.getConfigManager().removeAuthorizedPlayer(name);
                plugin.getActionLogger().log(player.getName(), "Retiro la autorizacion de " + name + " desde el GUI.");
                player.sendMessage(plugin.getMessageManager().get("player-deauthorized", "player", name));
                new PlayerManagementGUI(plugin).open(player);
            }
        }
    }
}
