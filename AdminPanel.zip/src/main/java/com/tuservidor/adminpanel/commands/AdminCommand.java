package com.tuservidor.adminpanel.commands;

import com.tuservidor.adminpanel.AdminPanelPlugin;
import com.tuservidor.adminpanel.gui.AdminGUI;
import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Comando principal "/adminpanel" con sus subcomandos.
 * Cada accion administrativa comprueba permisos a traves de PermissionManager
 * y queda registrada mediante ActionLogger.
 */
public class AdminCommand implements CommandExecutor, TabCompleter {

    private final AdminPanelPlugin plugin;
    private static final List<String> SUBCOMMANDS = List.of(
            "help", "gui", "reload", "info", "authorize", "deauthorize", "list"
    );

    public AdminCommand(AdminPanelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "help" -> sendHelp(sender);
            case "gui" -> openGui(sender);
            case "reload" -> reload(sender);
            case "info" -> showInfo(sender);
            case "authorize" -> authorize(sender, args);
            case "deauthorize" -> deauthorize(sender, args);
            case "list" -> listAuthorized(sender);
            default -> sendHelp(sender);
        }

        return true;
    }

    private void openGui(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessageManager().get("not-a-player"));
            return;
        }

        if (!plugin.getPermissionManager().canUsePanel(player)) {
            player.sendMessage(plugin.getMessageManager().get("no-permission"));
            return;
        }

        new AdminGUI(plugin).open(player);
    }

    private void reload(CommandSender sender) {
        if (sender instanceof Player player && !plugin.getPermissionManager().canReload(player)) {
            player.sendMessage(plugin.getMessageManager().get("no-permission"));
            return;
        }

        plugin.reload();
        sender.sendMessage(plugin.getMessageManager().get("reload-success"));
        plugin.getActionLogger().log(sender.getName(), "Recargo la configuracion del plugin.");
    }

    private void showInfo(CommandSender sender) {
        if (sender instanceof Player player && !plugin.getPermissionManager().canViewInfo(player)) {
            player.sendMessage(plugin.getMessageManager().get("no-permission"));
            return;
        }

        var server = plugin.getServer();
        double tps = server.getTPS().length > 0 ? server.getTPS()[0] : -1;

        sender.sendMessage(Component.text("== Informacion del servidor =="));
        sender.sendMessage(Component.text("Version: " + server.getVersion()));
        sender.sendMessage(Component.text("Jugadores en linea: " + server.getOnlinePlayers().size() + "/" + server.getMaxPlayers()));
        sender.sendMessage(Component.text("TPS: " + String.format("%.2f", tps)));
    }

    private void authorize(CommandSender sender, String[] args) {
        if (sender instanceof Player player && !plugin.getPermissionManager().canManagePlayers(player)) {
            player.sendMessage(plugin.getMessageManager().get("no-permission"));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(Component.text("Uso: /adminpanel authorize <jugador>"));
            return;
        }

        String targetName = args[1];
        plugin.getConfigManager().addAuthorizedPlayer(targetName);
        sender.sendMessage(plugin.getMessageManager().get("player-authorized", "player", targetName));
        plugin.getActionLogger().log(sender.getName(), "Autorizo al jugador " + targetName);
    }

    private void deauthorize(CommandSender sender, String[] args) {
        if (sender instanceof Player player && !plugin.getPermissionManager().canManagePlayers(player)) {
            player.sendMessage(plugin.getMessageManager().get("no-permission"));
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(Component.text("Uso: /adminpanel deauthorize <jugador>"));
            return;
        }

        String targetName = args[1];
        plugin.getConfigManager().removeAuthorizedPlayer(targetName);
        sender.sendMessage(plugin.getMessageManager().get("player-deauthorized", "player", targetName));
        plugin.getActionLogger().log(sender.getName(), "Retiro la autorizacion de " + targetName);
    }

    private void listAuthorized(CommandSender sender) {
        var list = plugin.getConfigManager().getAuthorizedPlayers();
        sender.sendMessage(Component.text("Jugadores autorizados (" + list.size() + "): " + String.join(", ", list)));
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Component.text("=== AdminPanel - Ayuda ==="));
        sender.sendMessage(Component.text("/adminpanel gui - Abre el panel de administracion"));
        sender.sendMessage(Component.text("/adminpanel reload - Recarga la configuracion"));
        sender.sendMessage(Component.text("/adminpanel info - Muestra informacion del servidor"));
        sender.sendMessage(Component.text("/adminpanel authorize <jugador> - Autoriza a un jugador"));
        sender.sendMessage(Component.text("/adminpanel deauthorize <jugador> - Retira la autorizacion"));
        sender.sendMessage(Component.text("/adminpanel list - Lista los jugadores autorizados"));
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            for (String sub : SUBCOMMANDS) {
                if (sub.startsWith(args[0].toLowerCase())) {
                    completions.add(sub);
                }
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("authorize") || args[0].equalsIgnoreCase("deauthorize"))) {
            for (Player p : plugin.getServer().getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    completions.add(p.getName());
                }
            }
        }

        return completions;
    }
}
