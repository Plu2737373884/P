package com.tuservidor.adminpanel.permissions;

import com.tuservidor.adminpanel.AdminPanelPlugin;
import org.bukkit.entity.Player;

/**
 * Punto unico de comprobacion de permisos para todo el plugin.
 * Los nodos de permiso son configurables desde config.yml (seccion "permissions"),
 * y la comprobacion real delega en LuckPerms cuando esta disponible.
 */
public class PermissionManager {

    private final AdminPanelPlugin plugin;

    public PermissionManager(AdminPanelPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean canUsePanel(Player player) {
        return hasPermission(player, "use", "adminpanel.use");
    }

    public boolean canManagePlayers(Player player) {
        return hasPermission(player, "manage-players", "adminpanel.players");
    }

    public boolean canReload(Player player) {
        return hasPermission(player, "reload", "adminpanel.reload");
    }

    public boolean canViewInfo(Player player) {
        return hasPermission(player, "view-info", "adminpanel.info");
    }

    private boolean hasPermission(Player player, String configKey, String fallbackNode) {
        String node = plugin.getConfigManager().getPermissionNode(configKey, fallbackNode);

        if (plugin.getLuckPermsHook().isEnabled()) {
            return plugin.getLuckPermsHook().hasPermission(player, node);
        }

        return player.hasPermission(node);
    }
}
