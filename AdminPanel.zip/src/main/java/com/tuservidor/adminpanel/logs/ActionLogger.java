package com.tuservidor.adminpanel.logs;

import com.tuservidor.adminpanel.AdminPanelPlugin;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Registra las acciones administrativas realizadas a traves del plugin
 * (autorizar/retirar jugadores, recargas, etc.) tanto en la consola como
 * en un archivo de texto dentro de la carpeta de datos del plugin.
 */
public class ActionLogger {

    private final AdminPanelPlugin plugin;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private PrintWriter writer;

    public ActionLogger(AdminPanelPlugin plugin) {
        this.plugin = plugin;
        setup();
    }

    private void setup() {
        if (!plugin.getConfigManager().isLoggingEnabled()) {
            return;
        }

        try {
            String fileName = plugin.getConfigManager().getLogFileName();
            Path path = plugin.getDataFolder().toPath().resolve(fileName);
            if (path.getParent() != null) {
                Files.createDirectories(path.getParent());
            }
            if (!Files.exists(path)) {
                Files.createFile(path);
            }
            this.writer = new PrintWriter(new FileWriter(path.toFile(), true), true);
        } catch (IOException ex) {
            plugin.getLogger().warning("No se pudo inicializar el archivo de logs: " + ex.getMessage());
        }
    }

    /** Registra una accion con marca de tiempo, autor de la accion y descripcion. */
    public void log(String executor, String action) {
        String line = "[" + LocalDateTime.now().format(formatter) + "] " + executor + " -> " + action;

        plugin.getLogger().info(line);

        if (writer != null) {
            writer.println(line);
        }
    }

    public void close() {
        if (writer != null) {
            writer.close();
        }
    }
}
