# AdminPanel

Plugin de administración para servidores **Paper 26.2** (Minecraft "Chaos Cubed", Java Edition).

## Requisitos

- **JDK 25** (Minecraft/Paper 26.x lo requiere obligatoriamente para compilar y ejecutar).
- Un servidor **Paper 26.2** (o superior compatible) para probarlo.
- (Opcional) **LuckPerms** instalado en el servidor si quieres permisos avanzados.

## 1. Compilar el .jar

Desde la raíz del proyecto (donde está `build.gradle`):

```bash
# Linux / macOS
./gradlew clean build

# Windows
gradlew.bat clean build
```

Si no tienes el wrapper de Gradle generado, créalo una vez con Gradle instalado localmente:

```bash
gradle wrapper --gradle-version 8.10
```

El `.jar` final quedará en:

```
build/libs/AdminPanel-1.0.0.jar
```

## 2. Instalar en el servidor Paper 26.2

1. Descarga Paper 26.2 desde https://papermc.io/downloads/paper y arráncalo al menos una vez para generar la carpeta `plugins/`.
2. Copia `AdminPanel-1.0.0.jar` a la carpeta `plugins/` del servidor.
3. (Opcional) Si vas a usar LuckPerms, coloca también su `.jar` en `plugins/` **antes** de arrancar, o reinicia el servidor tras instalarlo.
4. Arranca o reinicia el servidor.
5. Al iniciar, el plugin generará automáticamente:
   - `plugins/AdminPanel/config.yml`
   - `plugins/AdminPanel/logs/actions.log`

## 3. Uso básico

| Comando | Descripción |
|---|---|
| `/adminpanel gui` | Abre el panel de administración (GUI) |
| `/adminpanel reload` | Recarga `config.yml` |
| `/adminpanel info` | Muestra info del servidor (TPS, jugadores online, versión) |
| `/adminpanel authorize <jugador>` | Autoriza a un jugador |
| `/adminpanel deauthorize <jugador>` | Retira la autorización |
| `/adminpanel list` | Lista los jugadores autorizados |

Alias disponibles: `/ap`, `/admin`.

## 4. Permisos

Todos los nodos son configurables en `config.yml` (sección `permissions`), pero por defecto son:

- `adminpanel.use` — usar el comando base y abrir el panel
- `adminpanel.players` — gestionar jugadores autorizados
- `adminpanel.reload` — recargar la configuración
- `adminpanel.info` — ver información del servidor
- `adminpanel.*` — todos los anteriores

Si LuckPerms está presente y `settings.use-luckperms: true` en `config.yml`, las comprobaciones de permiso se hacen a través de su API; si no, se usa el sistema nativo de Bukkit.

## 5. Estructura del proyecto

```
AdminPanel/
├── build.gradle
├── settings.gradle
├── README.md
└── src/main/
    ├── resources/
    │   ├── plugin.yml
    │   └── config.yml
    └── java/com/tuservidor/adminpanel/
        ├── AdminPanelPlugin.java        (clase principal)
        ├── commands/AdminCommand.java
        ├── config/ConfigManager.java
        ├── util/MessageManager.java
        ├── permissions/PermissionManager.java
        ├── integration/LuckPermsHook.java
        ├── logs/ActionLogger.java
        └── gui/
            ├── AdminGUI.java
            ├── PlayerManagementGUI.java
            └── GUIListener.java
```

## Notas técnicas

- Usa `plugin.yml` clásico (no el nuevo `paper-plugin.yml` experimental), tal como lo soporta Paper 26.2.
- Los mensajes usan formato **MiniMessage** (`<green>`, `<red>`, etc.) en vez de códigos `&`, ya que es el estándar de Adventure en versiones modernas de Paper.
- Los GUIs se identifican por `InventoryHolder`, no por título, para evitar falsos positivos con inventarios de otros plugins.
